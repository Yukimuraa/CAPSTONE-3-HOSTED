<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

require_admin();

$page_title = "Billing Summary - CHMSU BAO";
$base_url = "..";

$service = isset($_GET['service']) ? sanitize_input($_GET['service']) : '';
$status = isset($_GET['status']) ? sanitize_input($_GET['status']) : '';
$start_date = isset($_GET['start_date']) ? sanitize_input($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? sanitize_input($_GET['end_date']) : '';

// Pagination
$rows_per_page = 20;
$current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($current_page - 1) * $rows_per_page;

// Collect rows from sources: Inventory orders (as sales)
$rows = [];

// Inventory orders as Item Sales - Group by batch_id
if ($service === '' || $service === 'items') {
	$sql2 = "SELECT 'Items' as service, 
				COALESCE(o.batch_id, CONCAT('ORDER-', o.id)) as billing_id,
				u.name as requester, 
				GROUP_CONCAT(DISTINCT i.name SEPARATOR ', ') as details,
				SUM(o.total_price) as amount,
				CASE WHEN COUNT(CASE WHEN o.status IN ('completed') THEN 1 END) = COUNT(*) THEN 'paid'
					 WHEN COUNT(CASE WHEN o.status = 'cancelled' THEN 1 END) > 0 THEN 'cancelled'
					 ELSE 'pending' END as pay_status,
				MAX(o.updated_at) as paid_at,
				MIN(o.created_at) as created_at,
				MAX(o.or_number) as or_number
		FROM orders o 
		JOIN user_accounts u ON u.id = o.user_id 
		JOIN inventory i ON i.id = o.inventory_id 
		WHERE 1=1";
	$params2 = []; $types2 = "";
	if (!empty($status)) { 
		if ($status === 'paid') { $sql2 .= " AND o.status = 'completed'"; }
		elseif ($status === 'pending') { $sql2 .= " AND o.status IN ('pending','approved')"; }
		elseif ($status === 'cancelled') { $sql2 .= " AND o.status = 'cancelled'"; }
	}
	if (!empty($start_date)) { $sql2 .= " AND DATE(o.created_at) >= ?"; $params2[] = $start_date; $types2 .= "s"; }
	if (!empty($end_date))   { $sql2 .= " AND DATE(o.created_at) <= ?"; $params2[] = $end_date;   $types2 .= "s"; }
	$sql2 .= " GROUP BY o.batch_id, u.id";
	$stmt2 = $conn->prepare($sql2);
	if (!empty($params2)) { $stmt2->bind_param($types2, ...$params2); }
	$stmt2->execute();
	$res2 = $stmt2->get_result();
	while ($r = $res2->fetch_assoc()) { $rows[] = $r; }
}

// Count total rows for pagination
$total_rows = count($rows);
$total_pages = ceil($total_rows / $rows_per_page);

// Apply pagination
$paginated_rows = array_slice($rows, $offset, $rows_per_page);

// Aggregates (calculate from all rows, not just paginated)
$total_amount = 0.0; $paid = 0.0; $pending_amt = 0.0;
foreach ($rows as $r) {
	$amt = (float)$r['amount'];
	$total_amount += $amt;
	if ($r['pay_status'] === 'paid') { $paid += $amt; }
	if ($r['pay_status'] === 'pending') { $pending_amt += $amt; }
}
?>

<?php include '../includes/header.php'; ?>

<div class="flex h-screen bg-gray-100">
	<?php include '../includes/admin_sidebar.php'; ?>
	<div class="flex-1 flex flex-col overflow-hidden">
		<header class="bg-white shadow-sm z-10">
			<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
				<h1 class="text-2xl font-semibold text-gray-900">Billing Summary</h1>
				<div class="flex items-center">
					<span class="text-gray-700 mr-2"><?php echo $_SESSION['user_name']; ?></span>
					<button class="md:hidden rounded-md p-2 inline-flex items-center justify-center text-gray-500 hover:text-gray-600 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500" id="menu-button">
						<span class="sr-only">Open menu</span>
						<i class="fas fa-bars"></i>
					</button>
				</div>
			</div>
		</header>

		<main class="flex-1 overflow-y-auto p-4">
			<div class="max-w-7xl mx-auto">
				<!-- Filters -->
				<div class="bg-white rounded-lg shadow p-6 mb-6">
					<h2 class="text-lg font-semibold text-gray-900 mb-4">Filter</h2>
					<form method="GET" action="billing_reports.php" class="grid grid-cols-1 md:grid-cols-6 gap-4">
						<div>
							<label class="block text-sm text-gray-700 mb-1">Service</label>
							<select name="service" class="w-full rounded-md border-gray-300">
								<option value="">All</option>
								<option value="items" <?php echo $service==='items'?'selected':''; ?>>Items</option>
							</select>
						</div>
						<div>
							<label class="block text-sm text-gray-700 mb-1">Payment Status</label>
							<select name="status" class="w-full rounded-md border-gray-300">
								<option value="">All</option>
								<?php foreach (['paid','pending','cancelled'] as $s): ?>
									<option value="<?php echo $s; ?>" <?php echo $status===$s?'selected':''; ?>><?php echo ucfirst($s); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div>
							<label class="block text-sm text-gray-700 mb-1">Start Date</label>
							<input type="date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>" class="w-full rounded-md border-gray-300">
						</div>
						<div>
							<label class="block text-sm text-gray-700 mb-1">End Date</label>
							<input type="date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>" class="w-full rounded-md border-gray-300">
						</div>
						<div class="md:col-span-2 flex items-end">
							<button type="submit" class="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"><i class="fas fa-filter mr-2"></i>Apply</button>
						</div>
					</form>
				</div>

				<!-- KPIs -->
				<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
					<div class="bg-white rounded-lg shadow p-4"><p class="text-gray-500 text-sm">Total Amount</p><h3 class="text-2xl font-bold text-emerald-600">₱<?php echo number_format($total_amount,2); ?></h3></div>
					<div class="bg-white rounded-lg shadow p-4"><p class="text-gray-500 text-sm">Paid</p><h3 class="text-2xl font-bold text-green-600">₱<?php echo number_format($paid,2); ?></h3></div>
					<div class="bg-white rounded-lg shadow p-4"><p class="text-gray-500 text-sm">Pending</p><h3 class="text-2xl font-bold text-yellow-600">₱<?php echo number_format($pending_amt,2); ?></h3></div>
				</div>

				<!-- Table -->
				<div class="bg-white rounded-lg shadow">
					<div class="px-4 py-5 border-b border-gray-200 sm:px-6 flex justify-between items-center">
						<h3 class="text-lg font-medium text-gray-900">Billing Records</h3>
						<div class="flex gap-2">
							<a href="download_report.php?type=billing&format=pdf&<?php echo http_build_query($_GET); ?>" class="bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700">
								<i class="fas fa-file-pdf mr-1"></i> PDF
							</a>
							<a href="download_report.php?type=billing&format=excel&<?php echo http_build_query($_GET); ?>" class="bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700">
								<i class="fas fa-file-excel mr-1"></i> Excel
							</a>
						</div>
					</div>
					<div class="overflow-x-auto">
						<table class="min-w-full divide-y divide-gray-200">
							<thead class="bg-gray-50">
								<tr>
									<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Billing ID</th>
									<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
									<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer / Details</th>
									<th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
									<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">OR No.</th>
									<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment Status</th>
									<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
								</tr>
							</thead>
							<tbody class="bg-white divide-y divide-gray-200">
								<?php if (count($paginated_rows) > 0): foreach ($paginated_rows as $r): ?>
								<tr>
									<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $r['billing_id']; ?></td>
									<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $r['service']; ?></td>
									<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($r['requester']); ?> — <?php echo htmlspecialchars($r['details']); ?></td>
									<td class="px-6 py-4 whitespace-nowrap text-sm text-right font-semibold text-emerald-600">₱<?php echo number_format((float)$r['amount'],2); ?></td>
									<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
										<?php if ($r['service'] === 'Items' && !empty($r['or_number'])): ?>
											<?php echo htmlspecialchars($r['or_number']); ?>
										<?php else: ?>
											<span class="text-gray-400">-</span>
										<?php endif; ?>
									</td>
									<td class="px-6 py-4 whitespace-nowrap text-sm">
										<?php $cls='bg-gray-100 text-gray-800'; if ($r['pay_status']==='paid') $cls='bg-green-100 text-green-800'; elseif ($r['pay_status']==='pending') $cls='bg-yellow-100 text-yellow-800'; elseif ($r['pay_status']==='cancelled') $cls='bg-red-100 text-red-800'; ?>
										<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $cls; ?>"><?php echo ucfirst($r['pay_status']); ?></span>
									</td>
									<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo format_date($r['created_at']); ?></td>
								</tr>
								<?php endforeach; ?>
								<tr class="bg-gray-50 font-bold">
									<td colspan="3" class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">Total:</td>
									<td class="px-6 py-4 whitespace-nowrap text-sm text-right font-semibold text-emerald-600">₱<?php echo number_format($total_amount, 2); ?></td>
									<td colspan="3" class="px-6 py-4"></td>
								</tr>
								<?php else: ?>
								<tr><td colspan="7" class="px-6 py-4 text-center text-sm text-gray-500">No billing records found</td></tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
					<?php if ($total_pages > 1): ?>
					<div class="px-4 py-3 border-t border-gray-200 sm:px-6">
						<nav class="flex items-center justify-between">
							<div class="flex-1 flex justify-between sm:hidden">
								<?php if ($current_page > 1): ?>
									<a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $current_page - 1])); ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">Previous</a>
								<?php endif; ?>
								<?php if ($current_page < $total_pages): ?>
									<a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $current_page + 1])); ?>" class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">Next</a>
								<?php endif; ?>
							</div>
							<div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
								<div>
									<p class="text-sm text-gray-700">
										Showing <span class="font-medium"><?php echo $offset + 1; ?></span> to <span class="font-medium"><?php echo min($offset + $rows_per_page, $total_rows); ?></span> of <span class="font-medium"><?php echo number_format($total_rows); ?></span> results
									</p>
								</div>
								<div>
									<nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
										<?php if ($current_page > 1): ?>
											<a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $current_page - 1])); ?>" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
												<i class="fas fa-chevron-left"></i>
											</a>
										<?php endif; ?>
										<?php
										$start_page = max(1, $current_page - 2);
										$end_page = min($total_pages, $current_page + 2);
										if ($start_page > 1): ?>
											<a href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">1</a>
											<?php if ($start_page > 2): ?><span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">...</span><?php endif; ?>
										<?php endif; ?>
										<?php for ($i = $start_page; $i <= $end_page; $i++): ?>
											<a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" class="<?php echo $i == $current_page ? 'z-10 bg-blue-50 border-blue-500 text-blue-600' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'; ?> relative inline-flex items-center px-4 py-2 border text-sm font-medium"><?php echo $i; ?></a>
										<?php endfor; ?>
										<?php if ($end_page < $total_pages): ?>
											<?php if ($end_page < $total_pages - 1): ?><span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">...</span><?php endif; ?>
											<a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50"><?php echo $total_pages; ?></a>
										<?php endif; ?>
										<?php if ($current_page < $total_pages): ?>
											<a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $current_page + 1])); ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
												<i class="fas fa-chevron-right"></i>
											</a>
										<?php endif; ?>
									</nav>
								</div>
							</div>
						</nav>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</main>
	</div>
</div>

<script>
	document.getElementById('menu-button').addEventListener('click', function() {
		document.getElementById('sidebar').classList.toggle('-translate-x-full');
	});
	window.onbeforeprint = function() { document.querySelectorAll('button').forEach(function(el){ el.style.display='none'; }); };
	window.onafterprint = function() { document.querySelectorAll('button').forEach(function(el){ el.style.display=''; }); };
</script>

    <script src="<?php echo $base_url ?? ''; ?>/assets/js/main.js"></script>
</body>
</html>


















