<?php
require_once 'config/database.php';

echo "<!DOCTYPE html><html><head><title>Fix Order ID Column</title></head><body>";
echo "<h2>Fix Order ID Column Size</h2>";

// Check current column size
$result = $conn->query("DESCRIBE orders");
while ($row = $result->fetch_assoc()) {
    if ($row['Field'] == 'order_id') {
        echo "<p>Current order_id column type: <strong>" . $row['Type'] . "</strong></p>";
    }
}

// Increase column size to VARCHAR(100) to accommodate longer IDs
$alter_sql = "ALTER TABLE orders MODIFY COLUMN order_id VARCHAR(100) UNIQUE NOT NULL";

if ($conn->query($alter_sql)) {
    echo "<p style='color:green;'>✓ Successfully expanded order_id column to VARCHAR(100)</p>";
} else {
    echo "<p style='color:red;'>✗ Error: " . $conn->error . "</p>";
}

// Check updated size
$result = $conn->query("DESCRIBE orders");
while ($row = $result->fetch_assoc()) {
    if ($row['Field'] == 'order_id') {
        echo "<p>Updated order_id column type: <strong>" . $row['Type'] . "</strong></p>";
    }
}

echo "<hr>";
echo "<h3>Now try placing your order again!</h3>";
echo "<p><a href='student/checkout.php'>Go to Checkout</a></p>";
echo "</body></html>";
?>


