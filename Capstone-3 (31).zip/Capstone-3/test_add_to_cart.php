<?php
session_start();
require_once 'config/database.php';

echo "<!DOCTYPE html><html><head><title>Test Add to Cart</title></head><body>";
echo "<h2>Test Add to Cart Function</h2>";

// Check if logged in
if (!isset($_SESSION['user_id'])) {
    echo "<p style='color:red;'>Not logged in!</p>";
    exit;
}

echo "<p>User ID: " . $_SESSION['user_id'] . "</p>";

// Get a random inventory item
$item_query = $conn->query("SELECT * FROM inventory WHERE in_stock = 1 LIMIT 1");
if ($item_query->num_rows == 0) {
    echo "<p style='color:red;'>No inventory items available!</p>";
    exit;
}

$test_item = $item_query->fetch_assoc();
echo "<h3>Test Item: " . $test_item['name'] . "</h3>";
echo "<p>ID: " . $test_item['id'] . "</p>";
echo "<p>Price: ₱" . $test_item['price'] . "</p>";
echo "<p>Available: " . $test_item['quantity'] . "</p>";

// Try to add to cart
$user_id = $_SESSION['user_id'];
$item_id = $test_item['id'];
$quantity = 1;
$size = null;

try {
    // Check if already in cart
    $check = $conn->prepare("SELECT id FROM cart WHERE user_id = ? AND inventory_id = ? AND size IS NULL");
    $check->bind_param("ii", $user_id, $item_id);
    $check->execute();
    $check_result = $check->get_result();
    
    if ($check_result->num_rows > 0) {
        echo "<p style='color:orange;'>Item already in cart. Let me update it...</p>";
        $cart_id = $check_result->fetch_assoc()['id'];
        $update = $conn->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id = ?");
        $update->bind_param("i", $cart_id);
        $update->execute();
        echo "<p style='color:green;'>✓ Updated quantity in cart</p>";
    } else {
        echo "<p>Adding new item to cart...</p>";
        $insert = $conn->prepare("INSERT INTO cart (user_id, inventory_id, quantity, size) VALUES (?, ?, ?, ?)");
        $insert->bind_param("iiis", $user_id, $item_id, $quantity, $size);
        if ($insert->execute()) {
            echo "<p style='color:green;'>✓ Item added to cart successfully!</p>";
        } else {
            echo "<p style='color:red;'>✗ Error: " . $insert->error . "</p>";
        }
    }
    
    // Check cart
    $cart_check = $conn->prepare("SELECT COUNT(*) as count FROM cart WHERE user_id = ?");
    $cart_check->bind_param("i", $user_id);
    $cart_check->execute();
    $cart_result = $cart_check->get_result();
    $cart_count = $cart_result->fetch_assoc()['count'];
    
    echo "<p><strong>Items in your cart: " . $cart_count . "</strong></p>";
    
    // Show cart contents
    $cart_items = $conn->prepare("SELECT c.*, i.name, i.price FROM cart c JOIN inventory i ON c.inventory_id = i.id WHERE c.user_id = ?");
    $cart_items->bind_param("i", $user_id);
    $cart_items->execute();
    $items_result = $cart_items->get_result();
    
    if ($items_result->num_rows > 0) {
        echo "<h3>Your Cart:</h3>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Item</th><th>Quantity</th><th>Price</th><th>Total</th></tr>";
        while ($item = $items_result->fetch_assoc()) {
            $total = $item['price'] * $item['quantity'];
            echo "<tr>";
            echo "<td>" . $item['name'] . "</td>";
            echo "<td>" . $item['quantity'] . "</td>";
            echo "<td>₱" . number_format($item['price'], 2) . "</td>";
            echo "<td>₱" . number_format($total, 2) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red;'>Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h3>Actions:</h3>";
echo "<ul>";
echo "<li><a href='student/cart.php'>View Shopping Cart</a></li>";
echo "<li><a href='student/inventory.php'>Go to Available Items</a></li>";
echo "<li><a href='test_cart.php'>Run Cart Debug</a></li>";
echo "</ul>";

echo "</body></html>";
?>


