<?php
/**
 * Quick Database Setup Redirect
 * This file redirects to the complete database setup script
 */

// Redirect to the setup script
header("Location: database/setup_complete.php");
exit();
?>









































































