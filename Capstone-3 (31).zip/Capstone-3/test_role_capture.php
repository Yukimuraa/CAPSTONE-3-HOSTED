<?php
// Test page to verify role is being captured correctly
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test Role Capture</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .debug { background: #f0f0f0; padding: 10px; margin: 10px 0; border-left: 4px solid #007cba; }
        form { background: white; padding: 20px; border: 1px solid #ddd; }
        select, input { padding: 8px; margin: 5px 0; width: 300px; }
    </style>
</head>
<body>
    <h2>Test Role Capture</h2>
    
    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <div class="debug">
            <h3>Form Data Received:</h3>
            <p><strong>User Type:</strong> <?php echo htmlspecialchars($_POST['user_type'] ?? 'NOT SET'); ?></p>
            <p><strong>Role:</strong> <?php echo htmlspecialchars($_POST['role'] ?? 'NOT SET'); ?></p>
            <p><strong>Role Index:</strong> <?php echo htmlspecialchars($_POST['role_index'] ?? 'NOT SET'); ?></p>
        </div>
    <?php endif; ?>
    
    <form method="POST" onsubmit="updateRoleField(); return true;">
        <div>
            <label>User Type:</label><br>
            <select id="user_type" name="user_type" onchange="updateRoleField();">
                <option value="">-- Select User Type --</option>
                <option value="student" data-role="student" data-index="1">Student</option>
                <option value="student" data-role="faculty" data-index="2">Faculty</option>
                <option value="student" data-role="staff" data-index="3">Staff</option>
                <option value="external" data-role="" data-index="4">External User</option>
            </select>
        </div>
        <div>
            <label>Role (Hidden):</label><br>
            <input type="text" id="role" name="role" value="" readonly style="background: #f0f0f0;">
            <small>This should update when you select an option</small>
        </div>
        <div>
            <label>Role Index (Hidden):</label><br>
            <input type="text" id="role_index" name="role_index" value="" readonly style="background: #f0f0f0;">
        </div>
        <button type="submit">Test Submit</button>
    </form>
    
    <script>
        function updateRoleField() {
            const userTypeSelect = document.getElementById("user_type");
            if (!userTypeSelect) return;
            
            const selectedIndex = userTypeSelect.selectedIndex;
            if (selectedIndex < 0) return;
            
            const selectedOption = userTypeSelect.options[selectedIndex];
            const roleField = document.getElementById("role");
            const roleIndexField = document.getElementById("role_index");
            
            if (!roleField) return;
            
            let role = selectedOption.getAttribute("data-role") || "";
            const roleIndex = selectedOption.getAttribute("data-index") || "";
            
            if (!role && selectedOption.text) {
                const optionText = selectedOption.text.trim().toLowerCase();
                if (optionText === "student") role = "student";
                else if (optionText === "faculty") role = "faculty";
                else if (optionText === "staff") role = "staff";
            }
            
            roleField.value = role;
            if (roleIndexField) {
                roleIndexField.value = roleIndex;
            }
            
            console.log("Selected:", selectedOption.text, "Role:", role, "Index:", roleIndex);
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            updateRoleField();
        });
    </script>
</body>
</html>


