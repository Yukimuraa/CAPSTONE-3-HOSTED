<footer class="bg-white-900 text-white py-6 mt-auto">
        <div class="container mx-auto px-4">
            <div class="text-center">
                <!-- <p>&copy; <?php echo date("Y"); ?> Carlos Hilado Memorial State University. All rights reserved.</p> -->
            </div>
        </div>
    </footer>

    <script src="<?php echo $base_url ?? ''; ?>/assets/js/main.js"></script>
</body>
</html>

