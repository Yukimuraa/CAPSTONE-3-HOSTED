-- Fix cart table: Convert empty strings to NULL for size column
-- This fixes the unique constraint violation issue
-- Run this script to clean up existing data

-- Update all empty string sizes to NULL
UPDATE cart SET size = NULL WHERE size = '';

-- Verify the fix
SELECT 
    COUNT(*) as total_rows,
    COUNT(size) as rows_with_size,
    COUNT(*) - COUNT(size) as rows_with_null_size
FROM cart;














