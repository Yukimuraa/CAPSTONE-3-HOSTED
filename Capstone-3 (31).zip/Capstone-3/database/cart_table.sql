-- Shopping Cart Table
-- This table stores items that users have added to their cart before checkout

CREATE TABLE IF NOT EXISTS cart (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    inventory_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    size VARCHAR(10) NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user_accounts(id) ON DELETE CASCADE,
    FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (user_id, inventory_id, size)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Modify orders table to support batch orders
-- Add a batch_id to group multiple items in one order
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS batch_id VARCHAR(50) NULL AFTER order_id,
ADD COLUMN IF NOT EXISTS size VARCHAR(10) NULL AFTER quantity;

-- Create index for batch orders
CREATE INDEX IF NOT EXISTS idx_orders_batch ON orders(batch_id);



