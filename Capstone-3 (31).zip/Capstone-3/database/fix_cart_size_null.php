<?php
// Fix cart table: Convert empty strings to NULL for size column
// This fixes the unique constraint violation issue
require_once '../config/database.php';

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Fix Cart Size NULL Issue</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .success { color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; margin: 10px 0; }
        .error { color: red; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 10px 0; }
        .info { color: blue; padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; margin: 10px 0; }
        h1 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Fix Cart Size NULL Issue</h1>
    <p>This script will convert empty strings to NULL in the cart table's size column to fix unique constraint violations.</p>
";

$errors = [];
$success = [];

// Check current state
$check_query = "SELECT 
    COUNT(*) as total_rows,
    SUM(CASE WHEN size = '' THEN 1 ELSE 0 END) as empty_string_count,
    SUM(CASE WHEN size IS NULL THEN 1 ELSE 0 END) as null_count,
    SUM(CASE WHEN size IS NOT NULL AND size != '' THEN 1 ELSE 0 END) as valid_size_count
FROM cart";

$result = $conn->query($check_query);
if ($result) {
    $stats = $result->fetch_assoc();
    echo "<div class='info'><h3>Current State:</h3>";
    echo "<table>";
    echo "<tr><th>Metric</th><th>Count</th></tr>";
    echo "<tr><td>Total cart items</td><td>" . $stats['total_rows'] . "</td></tr>";
    echo "<tr><td>Items with empty string size</td><td>" . $stats['empty_string_count'] . "</td></tr>";
    echo "<tr><td>Items with NULL size</td><td>" . $stats['null_count'] . "</td></tr>";
    echo "<tr><td>Items with valid size</td><td>" . $stats['valid_size_count'] . "</td></tr>";
    echo "</table></div>";
    
    if ($stats['empty_string_count'] > 0) {
        // Fix empty strings
        $update_query = "UPDATE cart SET size = NULL WHERE size = ''";
        if ($conn->query($update_query)) {
            $success[] = "✓ Updated " . $conn->affected_rows . " row(s) - converted empty strings to NULL";
            
            // Verify the fix
            $verify_result = $conn->query($check_query);
            if ($verify_result) {
                $new_stats = $verify_result->fetch_assoc();
                echo "<div class='success'><h3>After Fix:</h3>";
                echo "<table>";
                echo "<tr><th>Metric</th><th>Count</th></tr>";
                echo "<tr><td>Total cart items</td><td>" . $new_stats['total_rows'] . "</td></tr>";
                echo "<tr><td>Items with empty string size</td><td>" . $new_stats['empty_string_count'] . "</td></tr>";
                echo "<tr><td>Items with NULL size</td><td>" . $new_stats['null_count'] . "</td></tr>";
                echo "<tr><td>Items with valid size</td><td>" . $new_stats['valid_size_count'] . "</td></tr>";
                echo "</table></div>";
            }
        } else {
            $errors[] = "✗ Error updating cart table: " . $conn->error;
        }
    } else {
        $success[] = "✓ No empty strings found - database is already clean";
    }
} else {
    $errors[] = "✗ Error checking cart table: " . $conn->error;
}

// Display results
if (count($errors) > 0) {
    echo "<div class='error'><h3>Errors:</h3><ul>";
    foreach ($errors as $error) {
        echo "<li>$error</li>";
    }
    echo "</ul></div>";
}

if (count($success) > 0) {
    echo "<div class='success'><h3>Success:</h3><ul>";
    foreach ($success as $msg) {
        echo "<li>$msg</li>";
    }
    echo "</ul></div>";
}

if (count($errors) == 0) {
    echo "<div class='info'>
        <h3>Fix Complete!</h3>
        <p>The cart table has been cleaned up. Empty strings in the size column have been converted to NULL.</p>
        <p><strong>What was fixed:</strong></p>
        <ul>
            <li>Empty strings ('') in the size column are now NULL</li>
            <li>This prevents unique constraint violations when adding items to cart</li>
            <li>The code has also been updated to handle this properly going forward</li>
        </ul>
        <p><a href='../student/inventory.php'>Go to Student Inventory</a> | <a href='../staff/inventory.php'>Go to Staff Inventory</a></p>
    </div>";
}

echo "</body></html>";

$conn->close();
?>














