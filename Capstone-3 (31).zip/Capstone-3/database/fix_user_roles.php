<?php
// Fix user roles for existing users who registered before role column was added
require_once dirname(__DIR__) . '/config/database.php';

echo "<h2>Fixing User Roles</h2>";
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
    .success { color: green; padding: 10px; background: #e8f5e9; border-left: 4px solid green; margin: 10px 0; }
    .error { color: red; padding: 10px; background: #ffebee; border-left: 4px solid red; margin: 10px 0; }
    .info { color: blue; padding: 10px; background: #e3f2fd; border-left: 4px solid blue; margin: 10px 0; }
    table { border-collapse: collapse; background: white; margin: 10px 0; }
    th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
    th { background: #f2f2f2; }
</style>";

// Check if role column exists
$check_role = $conn->query("SHOW COLUMNS FROM user_accounts LIKE 'role'");
if ($check_role->num_rows == 0) {
    echo "<div class='error'>✗ Role column does not exist. Please run add_role_field.php first.</div>";
    echo "<br><a href='add_role_field.php'>Run Migration Script</a>";
    exit;
}

// Get all users with NULL role
$null_role_query = "SELECT id, name, email, user_type, role FROM user_accounts WHERE role IS NULL AND user_type = 'student'";
$result = $conn->query($null_role_query);

if ($result->num_rows > 0) {
    echo "<div class='info'>Found {$result->num_rows} user(s) with NULL role. These will be set to 'student' by default.</div>";
    echo "<h3>Users to Update:</h3>";
    echo "<table>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Current Role</th><th>Will Set To</th></tr>";
    
    $users_to_update = [];
    while ($user = $result->fetch_assoc()) {
        $users_to_update[] = $user;
        echo "<tr>";
        echo "<td>{$user['id']}</td>";
        echo "<td>{$user['name']}</td>";
        echo "<td>{$user['email']}</td>";
        echo "<td>" . ($user['role'] ?? 'NULL') . "</td>";
        echo "<td>student (default)</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Update all NULL roles to 'student'
    $update_query = "UPDATE user_accounts SET role = 'student' WHERE role IS NULL AND user_type = 'student'";
    if ($conn->query($update_query)) {
        $affected = $conn->affected_rows;
        echo "<div class='success'>✓ Updated $affected user(s) with default role='student'</div>";
    } else {
        echo "<div class='error'>✗ Error updating roles: " . $conn->error . "</div>";
    }
} else {
    echo "<div class='success'>✓ No users with NULL role found. All users have roles assigned.</div>";
}

// Show all users and their roles
echo "<h3>All Users and Their Roles:</h3>";
$all_users = $conn->query("SELECT id, name, email, user_type, role FROM user_accounts ORDER BY id");
echo "<table>";
echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>User Type</th><th>Role</th></tr>";

while ($user = $all_users->fetch_assoc()) {
    echo "<tr>";
    echo "<td>{$user['id']}</td>";
    echo "<td>{$user['name']}</td>";
    echo "<td>{$user['email']}</td>";
    echo "<td>{$user['user_type']}</td>";
    echo "<td>" . ($user['role'] ?? '<span style="color:red;">NULL</span>') . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "<br><a href='../admin/users.php'>Go to User Management</a>";


