-- Gym Event Blocking and Booking Rules Tables
-- This allows admins to block dates for school events and set booking restrictions

-- Table for blocked dates (school events, maintenance, etc.)
CREATE TABLE IF NOT EXISTS `gym_blocked_dates` (
  `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
  `event_name` VARCHAR(255) NOT NULL,
  `event_type` ENUM('school_event', 'maintenance', 'intramurals', 'ceremony', 'other') DEFAULT 'school_event',
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `description` TEXT,
  `affected_facilities` VARCHAR(255) DEFAULT 'all', -- 'all' or comma-separated facility IDs
  `blocked_for_user_types` VARCHAR(100) DEFAULT 'external', -- 'all', 'external', 'student', etc.
  `created_by` INT(11) NOT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_dates (start_date, end_date),
  INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table for booking rules (monthly restrictions for external users)
CREATE TABLE IF NOT EXISTS `gym_booking_rules` (
  `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
  `rule_name` VARCHAR(255) NOT NULL,
  `rule_type` ENUM('external_booking_months', 'booking_restriction', 'capacity_limit') DEFAULT 'external_booking_months',
  `user_type` ENUM('external', 'student', 'staff', 'all') NOT NULL,
  `allowed_months` VARCHAR(50), -- e.g., '3,4,5,6,7' for March-July
  `description` TEXT,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert default rule for external users (March to July only)
INSERT INTO `gym_booking_rules` (`rule_name`, `rule_type`, `user_type`, `allowed_months`, `description`, `is_active`) 
VALUES (
  'External User Booking Period', 
  'external_booking_months', 
  'external', 
  '3,4,5,6,7', 
  'External users (like Notre Dame) can only book gym from March to July for graduation ceremonies', 
  TRUE
) ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- Insert sample school events (Pinning Ceremony and Intramurals)
-- Note: Update the year as needed
INSERT INTO `gym_blocked_dates` (
  `event_name`, 
  `event_type`, 
  `start_date`, 
  `end_date`, 
  `description`, 
  `affected_facilities`, 
  `blocked_for_user_types`, 
  `created_by`, 
  `is_active`
) VALUES 
(
  'Pinning Ceremony', 
  'ceremony', 
  '2025-11-07', 
  '2025-11-07', 
  'Nursing Pinning Ceremony - Main Gymnasium reserved for school event', 
  'all', 
  'external', 
  1, 
  TRUE
),
(
  'School Intramurals', 
  'intramurals', 
  '2025-11-14', 
  '2025-11-20', 
  'Annual School Intramurals - All gym facilities reserved', 
  'all', 
  'all', 
  1, 
  TRUE
) ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

