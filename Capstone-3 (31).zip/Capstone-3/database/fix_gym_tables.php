<?php
require_once '../config/database.php';

echo "<!DOCTYPE html><html><head><title>Fix Gym Tables</title>
<style>body{font-family:Arial;max-width:800px;margin:50px auto;padding:20px;}
.success{color:green;padding:10px;background:#d4edda;border:1px solid #c3e6cb;margin:10px 0;}
.error{color:red;padding:10px;background:#f8d7da;border:1px solid #f5c6cb;margin:10px 0;}
</style></head><body><h1>Fix Missing Gym Tables</h1>";

// Create gym_blocked_dates table
$sql1 = "CREATE TABLE IF NOT EXISTS `gym_blocked_dates` (
  `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
  `event_name` VARCHAR(255) NOT NULL,
  `event_type` ENUM('school_event', 'maintenance', 'intramurals', 'ceremony', 'other') DEFAULT 'school_event',
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `description` TEXT,
  `affected_facilities` VARCHAR(255) DEFAULT 'all',
  `blocked_for_user_types` VARCHAR(100) DEFAULT 'external',
  `created_by` INT(11) NOT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_dates (start_date, end_date),
  INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

if ($conn->query($sql1)) {
    echo "<div class='success'>✓ Created gym_blocked_dates table</div>";
} else {
    echo "<div class='error'>Error creating table: " . $conn->error . "</div>";
}

// Insert sample events
$sql2 = "INSERT INTO `gym_blocked_dates` 
  (`event_name`, `event_type`, `start_date`, `end_date`, `description`, `affected_facilities`, `blocked_for_user_types`, `created_by`, `is_active`) 
VALUES 
  ('Pinning Ceremony', 'ceremony', '2025-11-07', '2025-11-07', 'Nursing Pinning Ceremony - Main Gymnasium reserved for school event', 'all', 'external', 1, TRUE),
  ('School Intramurals', 'intramurals', '2025-11-14', '2025-11-20', 'Annual School Intramurals - All gym facilities reserved', 'all', 'all', 1, TRUE)
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP";

if ($conn->query($sql2)) {
    echo "<div class='success'>✓ Inserted sample events (Pinning Ceremony & Intramurals)</div>";
} else {
    echo "<div class='error'>Error inserting events: " . $conn->error . "</div>";
}

echo "<hr><h2>✓ All Done!</h2>";
echo "<p><a href='../admin/gym_events.php'>Go to Gym Events Management</a></p>";
echo "</body></html>";

$conn->close();
?>

