<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if user is student
require_student();

$page_title = "Checkout - CHMSU BAO";
$base_url = "..";

$error = '';
$success = '';
$batch_id = '';

// Get cart items
$stmt = $conn->prepare("SELECT c.*, i.name, i.description, i.price, i.quantity as available_quantity, i.image_path 
                        FROM cart c 
                        JOIN inventory i ON c.inventory_id = i.id 
                        WHERE c.user_id = ? AND i.in_stock = 1
                        ORDER BY c.added_at ASC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

$cart_items = [];
$total_price = 0;

while ($row = $result->fetch_assoc()) {
    $cart_items[] = $row;
    $total_price += $row['price'] * $row['quantity'];
}

// If cart is empty, redirect to cart page
if (count($cart_items) === 0) {
    header("Location: cart.php");
    exit();
}

// Validate P.E. T-shirt and P.E. Pants requirement: They must be ordered together with matching quantities
$pe_tshirt_quantity = 0;
$pe_pants_quantity = 0;
$pe_tshirt_name = '';
$pe_pants_name = '';

foreach ($cart_items as $item) {
    $item_name_lower = strtolower($item['name']);
    // Check for P.E. T-shirt (various formats: "P.E T-Shirt", "P.E. T-Shirt", "PE T-Shirt", etc.)
    if ((stripos($item_name_lower, 'p.e') !== false || stripos($item_name_lower, 'pe') !== false) && 
        (stripos($item_name_lower, 't-shirt') !== false || stripos($item_name_lower, 'tshirt') !== false)) {
        $pe_tshirt_quantity += $item['quantity'];
        if (empty($pe_tshirt_name)) {
            $pe_tshirt_name = $item['name'];
        }
    }
    // Check for P.E. Pants (various formats: "P.E - Pants", "P.E. Pants", "PE Pants", etc.)
    if ((stripos($item_name_lower, 'p.e') !== false || stripos($item_name_lower, 'pe') !== false) && 
        stripos($item_name_lower, 'pants') !== false) {
        $pe_pants_quantity += $item['quantity'];
        if (empty($pe_pants_name)) {
            $pe_pants_name = $item['name'];
        }
    }
}

$has_pe_tshirt = $pe_tshirt_quantity > 0;
$has_pe_pants = $pe_pants_quantity > 0;
$pe_quantities_match = ($pe_tshirt_quantity === $pe_pants_quantity);

// Handle checkout form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_order'])) {
    // Validate P.E. T-shirt and P.E. Pants requirement before processing
    if ($has_pe_tshirt && !$has_pe_pants) {
        $error = "You cannot place an order with only P.E. T-shirt. P.E. Pants is required when ordering P.E. T-shirt. Please add P.E. Pants to your cart before proceeding.";
    } elseif ($has_pe_pants && !$has_pe_tshirt) {
        $error = "You cannot place an order with only P.E. Pants. P.E. T-shirt is required when ordering P.E. Pants. Please add P.E. T-shirt to your cart before proceeding.";
    } elseif ($has_pe_tshirt && $has_pe_pants && !$pe_quantities_match) {
        $error = "The quantity of P.E. T-shirts ({$pe_tshirt_quantity}) must match the quantity of P.E. Pants ({$pe_pants_quantity}). Please adjust your cart quantities so they match.";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
        // Generate unique batch ID for this order
        $batch_id = 'BATCH-' . date('Ymd') . '-' . date('His') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        // Check if batch_id already exists (very unlikely but good to check)
        $check_batch = $conn->prepare("SELECT id FROM orders WHERE batch_id = ?");
        $check_batch->bind_param("s", $batch_id);
        $check_batch->execute();
        if ($check_batch->get_result()->num_rows > 0) {
            // Add microseconds to make it unique
            $batch_id .= '-' . substr(microtime(true) * 10000, -4);
        }
        
        $order_ids = [];
        $request_details = [];
        $order_counter = 1; // Add counter for unique IDs
        
        // Process each cart item
        foreach ($cart_items as $item) {
            // Verify stock availability again
            $stock_check = $conn->prepare("SELECT quantity, size_quantities FROM inventory WHERE id = ? FOR UPDATE");
            $stock_check->bind_param("i", $item['inventory_id']);
            $stock_check->execute();
            $stock_result = $stock_check->get_result();
            $current_stock = $stock_result->fetch_assoc();
            
            // Check size-specific stock if size is provided
            if (!empty($item['size']) && !empty($current_stock['size_quantities'])) {
                $size_quantities = json_decode($current_stock['size_quantities'], true);
                if (is_array($size_quantities) && isset($size_quantities[$item['size']])) {
                    if ($size_quantities[$item['size']] < $item['quantity']) {
                        throw new Exception("Insufficient stock for " . $item['name'] . " size " . $item['size']);
                    }
                } else {
                    throw new Exception("Size " . $item['size'] . " not available for " . $item['name']);
                }
            } else {
                // Check total quantity
            if ($current_stock['quantity'] < $item['quantity']) {
                throw new Exception("Insufficient stock for " . $item['name']);
                }
            }
            
            // Generate unique order ID with counter and microtime for guaranteed uniqueness
            $base_time = date('Ymd-His');
            $micro = substr(microtime(true) * 10000, -4);
            $order_id = 'ORD-' . $base_time . '-' . $micro . '-' . str_pad($order_counter, 3, '0', STR_PAD_LEFT);
            
            // Verify uniqueness (should be unique now, but double check)
            $max_attempts = 5;
            for ($i = 0; $i < $max_attempts; $i++) {
                $check_order = $conn->prepare("SELECT id FROM orders WHERE order_id = ?");
                $check_order->bind_param("s", $order_id);
                $check_order->execute();
                
                if ($check_order->get_result()->num_rows == 0) {
                    break;
                }
                
                // If still duplicate, add extra random number
                $order_id = 'ORD-' . $base_time . '-' . $micro . '-' . str_pad($order_counter, 3, '0', STR_PAD_LEFT) . '-' . rand(10, 99);
            }
            
            $order_counter++; // Increment counter for next item
            
            $item_total = $item['price'] * $item['quantity'];
            
            // Create order (inventory will be deducted when admin marks as complete)
            $insert_order = $conn->prepare("INSERT INTO orders (order_id, batch_id, user_id, inventory_id, quantity, size, total_price, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
            $insert_order->bind_param("ssiiisd", $order_id, $batch_id, $_SESSION['user_id'], $item['inventory_id'], $item['quantity'], $item['size'], $item_total);
            $insert_order->execute();
            
            $order_ids[] = $order_id;
            
            // Build request details
            $detail = $item['quantity'] . " " . $item['name'];
            if (!empty($item['size'])) {
                $detail .= " (Size: " . $item['size'] . ")";
            }
            $request_details[] = $detail;
        }
        
        // Create a single request for all items
        $request_id = 'REQ-' . date('Ymd') . '-' . date('His') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        // Check if request_id exists
        for ($i = 0; $i < 10; $i++) {
            $check_request = $conn->prepare("SELECT id FROM requests WHERE request_id = ?");
            $check_request->bind_param("s", $request_id);
            $check_request->execute();
            
            if ($check_request->get_result()->num_rows == 0) {
                break;
            }
            
            $request_id = 'REQ-' . date('Ymd') . '-' . date('His') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        }
        
        $request_type = "Multiple Items Order";
        $request_desc = "Order for:\n" . implode("\n", $request_details);
        
        $insert_request = $conn->prepare("INSERT INTO requests (request_id, user_id, type, details, status) VALUES (?, ?, ?, ?, 'pending')");
        $insert_request->bind_param("siss", $request_id, $_SESSION['user_id'], $request_type, $request_desc);
        $insert_request->execute();
        
        // Clear cart
        $clear_cart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $clear_cart->bind_param("i", $_SESSION['user_id']);
        $clear_cart->execute();
        
        // Commit transaction
        $conn->commit();
        
        // Send notifications
        require_once '../includes/notification_functions.php';
        $user_id = $_SESSION['user_id'];
        $user_name = $_SESSION['user_sessions']['student']['user_name'] ?? 'Student';
        $item_count = count($cart_items);
        $item_names = array_slice(array_column($cart_items, 'name'), 0, 3);
        $items_text = implode(', ', $item_names);
        if ($item_count > 3) {
            $items_text .= " and " . ($item_count - 3) . " more";
        }
        
        // Notify user
        create_notification($user_id, "Order Submitted", "Your order (Batch ID: {$batch_id}) with {$item_count} item(s) has been submitted successfully. Please proceed to the cashier for payment.", "order", "student/cart.php");
        
        // Notify all admins
        create_notification_for_admins("New Order Received", "{$user_name} has placed a new order (Batch ID: {$batch_id}) with {$item_count} item(s): {$items_text}. Please review and process.", "order", "admin/orders.php");
        
        // Redirect to success page with batch_id
        header("Location: order_success.php?batch_id=" . $batch_id);
        exit();
        
        } catch (Exception $e) {
            // Rollback on error
            $conn->rollback();
            $error = "Error processing your order: " . $e->getMessage();
        }
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="flex h-screen bg-gray-100">
    <?php include '../includes/student_sidebar.php'; ?>
    
    <div class="flex-1 flex flex-col overflow-hidden">
        <!-- Top header -->
        <header class="bg-white shadow-sm z-10">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
                <h1 class="text-2xl font-semibold text-gray-900">Checkout</h1>
                <div class="flex items-center">
                    <span class="text-gray-700 mr-2"><?php echo $_SESSION['user_name']; ?></span>
                    <button class="md:hidden rounded-md p-2 inline-flex items-center justify-center text-gray-500 hover:text-gray-600 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-emerald-500" id="menu-button">
                        <span class="sr-only">Open menu</span>
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
            </div>
        </header>
        
        <!-- Main content -->
        <main class="flex-1 overflow-y-auto p-4">
            <div class="max-w-5xl mx-auto">
                <?php if (!empty($error)): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4">
                        <p><?php echo $error; ?></p>
                    </div>
                <?php endif; ?>
                
                <?php if ($has_pe_tshirt && !$has_pe_pants): ?>
                    <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-4 mb-4">
                        <div class="flex items-start">
                            <i class="fas fa-exclamation-triangle text-yellow-600 text-xl mr-3 mt-0.5"></i>
                            <div>
                                <p class="font-semibold">P.E. Pants Required</p>
                                <p class="text-sm mt-1">You have <strong><?php echo htmlspecialchars($pe_tshirt_name); ?></strong> (Quantity: <?php echo $pe_tshirt_quantity; ?>) in your cart. P.E. Pants is required when ordering P.E. T-shirt. Please add <?php echo $pe_tshirt_quantity; ?> P.E. Pants to your cart before placing your order.</p>
                            </div>
                        </div>
                    </div>
                <?php elseif ($has_pe_pants && !$has_pe_tshirt): ?>
                    <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-4 mb-4">
                        <div class="flex items-start">
                            <i class="fas fa-exclamation-triangle text-yellow-600 text-xl mr-3 mt-0.5"></i>
                            <div>
                                <p class="font-semibold">P.E. T-shirt Required</p>
                                <p class="text-sm mt-1">You have <strong><?php echo htmlspecialchars($pe_pants_name); ?></strong> (Quantity: <?php echo $pe_pants_quantity; ?>) in your cart. P.E. T-shirt is required when ordering P.E. Pants. Please add <?php echo $pe_pants_quantity; ?> P.E. T-shirt(s) to your cart before placing your order.</p>
                            </div>
                        </div>
                    </div>
                <?php elseif ($has_pe_tshirt && $has_pe_pants && !$pe_quantities_match): ?>
                    <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-4 mb-4">
                        <div class="flex items-start">
                            <i class="fas fa-exclamation-triangle text-yellow-600 text-xl mr-3 mt-0.5"></i>
                            <div>
                                <p class="font-semibold">Quantity Mismatch</p>
                                <p class="text-sm mt-1">You have <strong><?php echo $pe_tshirt_quantity; ?> P.E. T-shirt(s)</strong> but only <strong><?php echo $pe_pants_quantity; ?> P.E. Pants</strong> in your cart. The quantities must match. Please adjust your cart so you have <?php echo $pe_tshirt_quantity; ?> P.E. Pants to match your <?php echo $pe_tshirt_quantity; ?> P.E. T-shirt(s).</p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Order Items -->
                    <div class="lg:col-span-2">
                        <div class="bg-white rounded-lg shadow">
                            <div class="px-4 py-5 border-b border-gray-200 sm:px-6">
                                <h3 class="text-lg font-medium text-gray-900">Order Items</h3>
                                <p class="mt-1 text-sm text-gray-500">Review your items before placing the order</p>
                            </div>
                            <div class="divide-y divide-gray-200">
                                <?php foreach ($cart_items as $item): ?>
                                    <div class="p-4 sm:p-6">
                                        <div class="flex items-start">
                                            <div class="flex-shrink-0 h-20 w-20 bg-gray-100 rounded-md flex items-center justify-center">
                                                <?php if (!empty($item['image_path']) && file_exists('../' . $item['image_path'])): ?>
                                                    <img src="<?php echo '../' . $item['image_path']; ?>" alt="<?php echo $item['name']; ?>" class="h-full w-full object-contain rounded-md">
                                                <?php else: ?>
                                                    <i class="fas fa-box text-gray-400 text-2xl"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div class="ml-4 flex-1">
                                                <h4 class="text-base font-medium text-gray-900"><?php echo $item['name']; ?></h4>
                                                <p class="text-sm text-gray-500 mt-1"><?php echo $item['description']; ?></p>
                                                <?php if (!empty($item['size'])): ?>
                                                    <p class="text-sm text-gray-600 mt-1">Size: <span class="font-medium"><?php echo $item['size']; ?></span></p>
                                                <?php endif; ?>
                                                <div class="mt-2 flex items-center justify-between">
                                                    <p class="text-sm text-gray-600">
                                                        Quantity: <span class="font-medium"><?php echo $item['quantity']; ?></span>
                                                    </p>
                                                    <p class="text-base font-bold text-gray-900">
                                                        ₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <a href="cart.php" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                                <i class="fas fa-arrow-left mr-2"></i> Back to Cart
                            </a>
                        </div>
                    </div>
                    
                    <!-- Order Summary and Confirmation -->
                    <div class="lg:col-span-1">
                        <div class="bg-white rounded-lg shadow sticky top-4">
                            <div class="px-4 py-5 border-b border-gray-200 sm:px-6">
                                <h3 class="text-lg font-medium text-gray-900">Order Summary</h3>
                            </div>
                            <div class="px-4 py-5 sm:p-6">
                                <div class="space-y-4">
                                    <div class="flex justify-between text-base">
                                        <span class="text-gray-600">Items:</span>
                                        <span class="font-medium"><?php echo count($cart_items); ?></span>
                                    </div>
                                    <div class="flex justify-between text-base">
                                        <span class="text-gray-600">Subtotal:</span>
                                        <span class="font-medium">₱<?php echo number_format($total_price, 2); ?></span>
                                    </div>
                                    <div class="pt-4 border-t border-gray-200">
                                        <div class="flex justify-between text-lg font-bold">
                                            <span>Total:</span>
                                            <span class="text-emerald-600">₱<?php echo number_format($total_price, 2); ?></span>
                                        </div>
                                    </div>
                                    
                                    <form method="POST" action="" class="pt-4">
                                        <button type="button" id="place-order-btn" class="w-full inline-flex justify-center items-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 <?php echo (($has_pe_tshirt && !$has_pe_pants) || ($has_pe_pants && !$has_pe_tshirt) || ($has_pe_tshirt && $has_pe_pants && !$pe_quantities_match)) ? 'opacity-50 cursor-not-allowed' : ''; ?>" <?php echo (($has_pe_tshirt && !$has_pe_pants) || ($has_pe_pants && !$has_pe_tshirt) || ($has_pe_tshirt && $has_pe_pants && !$pe_quantities_match)) ? 'disabled' : ''; ?>>
                                            <i class="fas fa-check-circle mr-2"></i> Place Order
                                        </button>
                                    </form>
                                    
                                    <?php if ($has_pe_tshirt && !$has_pe_pants): ?>
                                        <div class="mt-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                                            <p class="text-xs text-yellow-800">
                                                <i class="fas fa-info-circle mr-1"></i>
                                                Cannot place order: P.E. Pants is required when ordering P.E. T-shirt.
                                            </p>
                                        </div>
                                    <?php elseif ($has_pe_pants && !$has_pe_tshirt): ?>
                                        <div class="mt-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                                            <p class="text-xs text-yellow-800">
                                                <i class="fas fa-info-circle mr-1"></i>
                                                Cannot place order: P.E. T-shirt is required when ordering P.E. Pants.
                                            </p>
                                        </div>
                                    <?php elseif ($has_pe_tshirt && $has_pe_pants && !$pe_quantities_match): ?>
                                        <div class="mt-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                                            <p class="text-xs text-yellow-800">
                                                <i class="fas fa-info-circle mr-1"></i>
                                                Cannot place order: P.E. T-shirt quantity (<?php echo $pe_tshirt_quantity; ?>) must match P.E. Pants quantity (<?php echo $pe_pants_quantity; ?>).
                                            </p>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="mt-4 p-3 bg-blue-50 rounded-lg">
                                        <p class="text-xs text-blue-800">
                                            <i class="fas fa-info-circle mr-1"></i>
                                            After placing your order, please proceed to the cashier for payment.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Confirmation Modal -->
<div id="confirmationModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md mx-4">
        <div class="flex items-center mb-4">
            <div class="flex-shrink-0">
                <i class="fas fa-exclamation-triangle text-yellow-500 text-2xl"></i>
            </div>
            <div class="ml-3">
                <h3 class="text-lg font-medium text-gray-900">Confirm Order</h3>
            </div>
        </div>
        
        <div class="mb-6">
            <p class="text-sm text-gray-600 mb-4">Are you sure you want to place this order?</p>
            
            <div class="bg-gray-50 rounded-lg p-4">
                <div class="flex justify-between items-center mb-2">
                    <span class="text-sm font-medium text-gray-700">Total Items:</span>
                    <span class="text-sm text-gray-900"><?php echo count($cart_items); ?></span>
                </div>
                <div class="flex justify-between items-center font-semibold text-lg pt-2 border-t border-gray-200">
                    <span class="text-gray-900">Total Amount:</span>
                    <span class="text-emerald-600">₱<?php echo number_format($total_price, 2); ?></span>
                </div>
            </div>
            
            <div class="mt-4 p-3 bg-yellow-50 rounded-lg">
                <p class="text-xs text-yellow-800">
                    <i class="fas fa-exclamation-circle mr-1"></i>
                    This action cannot be undone. Please ensure all items and quantities are correct.
                </p>
            </div>
        </div>
        
        <form method="POST" action="" id="checkout-form">
            <input type="hidden" name="confirm_order" value="1">
            <div class="flex justify-end space-x-3">
                <button type="button" id="cancel-order" class="inline-flex justify-center py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                    <i class="fas fa-times mr-2"></i>
                    Cancel
                </button>
                <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                    <i class="fas fa-check mr-2"></i>
                    Yes, Place Order
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    // Mobile menu toggle
    document.getElementById('menu-button').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('-translate-x-full');
    });
    
    // Confirmation modal
    const placeOrderBtn = document.getElementById('place-order-btn');
    const confirmationModal = document.getElementById('confirmationModal');
    const cancelOrderBtn = document.getElementById('cancel-order');
    
    placeOrderBtn.addEventListener('click', function() {
        <?php if ($has_pe_tshirt && !$has_pe_pants): ?>
            // Prevent order placement if P.E. T-shirt is in cart without P.E. pants
            alert('You cannot place an order with only P.E. T-shirt. P.E. Pants is required when ordering P.E. T-shirt. Please add P.E. Pants to your cart before proceeding.');
            return false;
        <?php elseif ($has_pe_pants && !$has_pe_tshirt): ?>
            // Prevent order placement if P.E. Pants is in cart without P.E. T-shirt
            alert('You cannot place an order with only P.E. Pants. P.E. T-shirt is required when ordering P.E. Pants. Please add P.E. T-shirt to your cart before proceeding.');
            return false;
        <?php elseif ($has_pe_tshirt && $has_pe_pants && !$pe_quantities_match): ?>
            // Prevent order placement if quantities don't match
            alert('The quantity of P.E. T-shirts (<?php echo $pe_tshirt_quantity; ?>) must match the quantity of P.E. Pants (<?php echo $pe_pants_quantity; ?>). Please adjust your cart quantities so they match.');
            return false;
        <?php else: ?>
            confirmationModal.classList.remove('hidden');
        <?php endif; ?>
    });
    
    cancelOrderBtn.addEventListener('click', function() {
        confirmationModal.classList.add('hidden');
    });
    
    // Hide modal when clicking outside
    confirmationModal.addEventListener('click', function(e) {
        if (e.target === confirmationModal) {
            confirmationModal.classList.add('hidden');
        }
    });
    
    // Hide modal with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && !confirmationModal.classList.contains('hidden')) {
            confirmationModal.classList.add('hidden');
        }
    });
</script>

<?php include '../includes/footer.php'; ?>


