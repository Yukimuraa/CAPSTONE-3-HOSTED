<?php
// Check and fix a specific user's role
require_once 'config/database.php';

$email = $_GET['email'] ?? 'benjamincarin33@gmail.com';

echo "<h2>Check and Fix User Role</h2>";
echo "<style>
    body { font-family: Arial; padding: 20px; background: #f5f5f5; }
    .success { color: green; padding: 10px; background: #e8f5e9; border-left: 4px solid green; margin: 10px 0; }
    .error { color: red; padding: 10px; background: #ffebee; border-left: 4px solid red; margin: 10px 0; }
    .info { color: blue; padding: 10px; background: #e3f2fd; border-left: 4px solid blue; margin: 10px 0; }
    table { border-collapse: collapse; background: white; margin: 10px 0; }
    th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
    th { background: #f2f2f2; }
    form { background: white; padding: 20px; margin: 10px 0; }
</style>";

// Check if role column exists
$check_role = $conn->query("SHOW COLUMNS FROM user_accounts LIKE 'role'");
if ($check_role->num_rows == 0) {
    echo "<div class='error'>✗ Role column does not exist. Please run add_role_field.php first.</div>";
    echo "<br><a href='database/add_role_field.php'>Run Migration Script</a>";
    exit;
}

// Get user
$stmt = $conn->prepare("SELECT * FROM user_accounts WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "<div class='error'>User not found: $email</div>";
    exit;
}

$user = $result->fetch_assoc();

echo "<h3>Current User Data:</h3>";
echo "<table>";
echo "<tr><th>Field</th><th>Value</th></tr>";
echo "<tr><td>ID</td><td>{$user['id']}</td></tr>";
echo "<tr><td>Name</td><td>{$user['name']}</td></tr>";
echo "<tr><td>Email</td><td>{$user['email']}</td></tr>";
echo "<tr><td>User Type</td><td>{$user['user_type']}</td></tr>";
echo "<tr><td>Role</td><td>" . ($user['role'] ?? '<span style="color:red;">NULL</span>') . "</td></tr>";
echo "</table>";

if (empty($user['role']) || $user['role'] == 'student') {
    echo "<div class='info'>User role is NULL or 'student'. You can update it below.</div>";
    
    if (isset($_POST['update_role'])) {
        $new_role = $_POST['new_role'];
        $update_stmt = $conn->prepare("UPDATE user_accounts SET role = ? WHERE email = ?");
        $update_stmt->bind_param("ss", $new_role, $email);
        
        if ($update_stmt->execute()) {
            echo "<div class='success'>✓ Role updated successfully to: $new_role</div>";
            echo "<meta http-equiv='refresh' content='2;url=admin/users.php'>";
            echo "<p>Redirecting to admin panel...</p>";
        } else {
            echo "<div class='error'>✗ Error updating role: " . $conn->error . "</div>";
        }
    } else {
        echo "<form method='POST'>";
        echo "<h4>Update Role:</h4>";
        echo "<select name='new_role'>";
        echo "<option value='student'" . ($user['role'] == 'student' ? ' selected' : '') . ">Student</option>";
        echo "<option value='faculty'" . ($user['role'] == 'faculty' ? ' selected' : '') . ">Faculty</option>";
        echo "<option value='staff'" . ($user['role'] == 'staff' ? ' selected' : '') . ">Staff</option>";
        echo "</select>";
        echo "<button type='submit' name='update_role'>Update Role</button>";
        echo "</form>";
    }
} else {
    echo "<div class='success'>✓ User role is already set to: {$user['role']}</div>";
}

echo "<br><a href='admin/users.php'>Go to User Management</a>";


