<?php
/**
 * Test file to update booking status from Unknown to Cancelled
 * For booking: GYM-2025-127
 * This version checks for triggers, constraints, and column types
 */

require_once 'config/database.php';

$booking_id = 'GYM-2025-127';

echo "<h2>Update Booking Status - Complete Diagnostic</h2>";
echo "<p>Booking ID: <strong>{$booking_id}</strong></p>";

// Step 1: Check table structure
echo "<h3>Step 1: Table Structure Analysis</h3>";
$structure_query = "SHOW COLUMNS FROM bookings LIKE 'status'";
$structure_result = $conn->query($structure_query);

if ($structure_result && $structure_result->num_rows > 0) {
    $status_col = $structure_result->fetch_assoc();
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse; margin-bottom: 20px;'>";
    echo "<tr><th>Property</th><th>Value</th></tr>";
    foreach ($status_col as $key => $value) {
        echo "<tr><td><strong>" . htmlspecialchars($key) . "</strong></td><td>" . htmlspecialchars($value ?? 'NULL') . "</td></tr>";
    }
    echo "</table>";
    
    // Check if it's an ENUM
    if (stripos($status_col['Type'], 'enum') !== false) {
        echo "<p style='color: orange;'><strong>⚠️ Status column is an ENUM type!</strong></p>";
        echo "<p>ENUM values: <strong>" . htmlspecialchars($status_col['Type']) . "</strong></p>";
        
        // Extract ENUM values
        preg_match("/enum\s*\((.+)\)/i", $status_col['Type'], $matches);
        if (isset($matches[1])) {
            $enum_values = array_map(function($v) {
                return trim($v, "'\"");
            }, explode(',', $matches[1]));
            echo "<p>Allowed values: " . implode(', ', $enum_values) . "</p>";
            
            if (!in_array('cancelled', $enum_values) && !in_array("'cancelled'", $enum_values)) {
                echo "<p style='color: red;'><strong>❌ 'cancelled' is NOT in the ENUM list!</strong></p>";
                echo "<p>We need to add 'cancelled' to the ENUM or use an existing value.</p>";
            } else {
                echo "<p style='color: green;'>✅ 'cancelled' is in the ENUM list.</p>";
            }
        }
    }
} else {
    echo "<p style='color: red;'>Could not get column structure.</p>";
}

// Step 2: Check for triggers
echo "<hr><h3>Step 2: Checking for Triggers</h3>";
$trigger_query = "SHOW TRIGGERS LIKE 'bookings'";
$trigger_result = $conn->query($trigger_query);

if ($trigger_result && $trigger_result->num_rows > 0) {
    echo "<p style='color: orange;'><strong>⚠️ Found triggers on bookings table:</strong></p>";
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
    echo "<tr><th>Trigger</th><th>Event</th><th>Timing</th></tr>";
    while ($trigger = $trigger_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($trigger['Trigger']) . "</td>";
        echo "<td>" . htmlspecialchars($trigger['Event']) . "</td>";
        echo "<td>" . htmlspecialchars($trigger['Timing']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: green;'>✅ No triggers found on bookings table.</p>";
}

// Step 3: Get current booking
echo "<hr><h3>Step 3: Current Booking Status</h3>";
$check_stmt = $conn->prepare("SELECT booking_id, status, facility_type FROM bookings WHERE booking_id = ?");
$check_stmt->bind_param("s", $booking_id);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows === 0) {
    echo "<p style='color: red;'>❌ Booking not found!</p>";
    exit;
}

$booking = $result->fetch_assoc();
echo "<p>Current status: <strong>" . var_export($booking['status'], true) . "</strong></p>";

// Step 4: Try the update with error checking
echo "<hr><h3>Step 4: Attempting Update</h3>";

// First, let's try to see what happens if we check the column definition
$test_update = "UPDATE bookings SET status = 'cancelled' WHERE booking_id = '{$booking_id}'";
echo "<p>Executing: <code>" . htmlspecialchars($test_update) . "</code></p>";

// Enable error reporting
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    if ($conn->query($test_update)) {
        $affected = $conn->affected_rows;
        echo "<p style='color: green;'>✅ Query executed. Affected rows: {$affected}</p>";
    }
} catch (mysqli_sql_exception $e) {
    echo "<p style='color: red;'><strong>❌ SQL Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Error Code: " . $e->getCode() . "</p>";
}

// Step 5: Verify the update
echo "<hr><h3>Step 5: Verification</h3>";
$verify_stmt = $conn->prepare("SELECT status, HEX(status) as status_hex, LENGTH(status) as status_length FROM bookings WHERE booking_id = ?");
$verify_stmt->bind_param("s", $booking_id);
$verify_stmt->execute();
$verify_result = $verify_stmt->get_result();
$updated = $verify_result->fetch_assoc();

echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
echo "<tr><th>Field</th><th>Value</th></tr>";
echo "<tr><td>Status (Display)</td><td><strong>" . htmlspecialchars($updated['status'] ?: 'NULL/Empty') . "</strong></td></tr>";
echo "<tr><td>Status (Raw)</td><td>" . var_export($updated['status'], true) . "</td></tr>";
echo "<tr><td>Status (HEX)</td><td>" . htmlspecialchars($updated['status_hex']) . "</td></tr>";
echo "<tr><td>Status Length</td><td>{$updated['status_length']}</td></tr>";
echo "</table>";

// Step 6: If still empty, try ALTER TABLE approach
if (empty($updated['status']) || $updated['status'] === '') {
    echo "<hr><h3>Step 6: Attempting Fix - Modify Column</h3>";
    
    // Check current column type
    $col_info = $conn->query("SHOW COLUMNS FROM bookings WHERE Field = 'status'");
    $col_data = $col_info->fetch_assoc();
    $current_type = $col_data['Type'];
    
    echo "<p>Current column type: <strong>" . htmlspecialchars($current_type) . "</strong></p>";
    
    // If it's an ENUM without 'cancelled', we need to modify it
    if (stripos($current_type, 'enum') !== false) {
        echo "<p style='color: orange;'>Attempting to modify ENUM to include 'cancelled'...</p>";
        
        // Extract existing ENUM values
        preg_match("/enum\s*\((.+)\)/i", $current_type, $enum_match);
        if (isset($enum_match[1])) {
            $existing_values = $enum_match[1];
            
            // Check if 'cancelled' is already there
            if (stripos($existing_values, 'cancelled') === false) {
                // Add 'cancelled' to the ENUM
                $new_enum = $existing_values . ", 'cancelled'";
                $alter_sql = "ALTER TABLE bookings MODIFY COLUMN status ENUM({$new_enum})";
                
                echo "<p>Executing: <code>" . htmlspecialchars($alter_sql) . "</code></p>";
                
                try {
                    if ($conn->query($alter_sql)) {
                        echo "<p style='color: green;'>✅ Column modified successfully!</p>";
                        
                        // Now try the update again
                        $retry_update = "UPDATE bookings SET status = 'cancelled' WHERE booking_id = '{$booking_id}'";
                        if ($conn->query($retry_update)) {
                            echo "<p style='color: green;'>✅ Status updated to 'cancelled'!</p>";
                            
                            // Final verification
                            $final_check = $conn->query("SELECT status FROM bookings WHERE booking_id = '{$booking_id}'");
                            $final = $final_check->fetch_assoc();
                            echo "<p>Final status: <strong style='color: green; font-size: 18px;'>" . htmlspecialchars($final['status']) . "</strong></p>";
                        }
                    }
                } catch (mysqli_sql_exception $e) {
                    echo "<p style='color: red;'>❌ Error modifying column: " . htmlspecialchars($e->getMessage()) . "</p>";
                }
            } else {
                echo "<p style='color: green;'>✅ 'cancelled' is already in the ENUM. The issue might be something else.</p>";
            }
        }
    } else {
        // Not an ENUM, try a different approach
        echo "<p>Column is not an ENUM. Trying direct value assignment...</p>";
        
        // Try using a variable
        $status_value = 'cancelled';
        $var_update = $conn->prepare("UPDATE bookings SET status = ? WHERE booking_id = ?");
        $var_update->bind_param("ss", $status_value, $booking_id);
        
        if ($var_update->execute()) {
            echo "<p style='color: green;'>✅ Update with variable succeeded!</p>";
            
            $final_check2 = $conn->query("SELECT status FROM bookings WHERE booking_id = '{$booking_id}'");
            $final2 = $final_check2->fetch_assoc();
            echo "<p>Final status: <strong style='color: green; font-size: 18px;'>" . htmlspecialchars($final2['status']) . "</strong></p>";
        } else {
            echo "<p style='color: red;'>❌ Update with variable failed: " . $conn->error . "</p>";
        }
    }
}

echo "<hr>";
echo "<p><a href='external/gym.php' style='padding: 10px 20px; background: #3b82f6; color: white; text-decoration: none; border-radius: 5px;'>← Back to Gym Booking Page</a></p>";

$conn->close();
?>
