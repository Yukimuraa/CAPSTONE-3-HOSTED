<?php
session_start();
require_once 'config/database.php';

echo "<!DOCTYPE html><html><head><title>Cart Debug</title></head><body>";
echo "<h2>Cart System Debug</h2>";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<p style='color:red;'>❌ User not logged in. Session user_id not set.</p>";
    echo "<p>Session data: <pre>" . print_r($_SESSION, true) . "</pre></p>";
} else {
    echo "<p style='color:green;'>✓ User logged in. User ID: " . $_SESSION['user_id'] . "</p>";
    
    // Check if cart table exists
    $check_table = $conn->query("SHOW TABLES LIKE 'cart'");
    if ($check_table->num_rows == 0) {
        echo "<p style='color:red;'>❌ Cart table does not exist!</p>";
        echo "<p><a href='database/setup_cart_system.php'>Click here to create cart table</a></p>";
    } else {
        echo "<p style='color:green;'>✓ Cart table exists</p>";
        
        // Check cart contents
        $stmt = $conn->prepare("SELECT c.*, i.name, i.price FROM cart c LEFT JOIN inventory i ON c.inventory_id = i.id WHERE c.user_id = ?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        
        echo "<p>Cart items for user " . $_SESSION['user_id'] . ": <strong>" . $result->num_rows . "</strong></p>";
        
        if ($result->num_rows > 0) {
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>ID</th><th>Item Name</th><th>Quantity</th><th>Size</th><th>Price</th><th>Added At</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>" . ($row['size'] ?? '-') . "</td>";
                echo "<td>₱" . number_format($row['price'], 2) . "</td>";
                echo "<td>" . $row['added_at'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p style='color:orange;'>⚠ Cart is empty. Try adding items first.</p>";
        }
        
        // Check all cart items (for all users)
        $all_cart = $conn->query("SELECT COUNT(*) as total FROM cart");
        $total_cart_items = $all_cart->fetch_assoc()['total'];
        echo "<p>Total cart items in database (all users): <strong>" . $total_cart_items . "</strong></p>";
        
        // Check inventory items
        $inventory = $conn->query("SELECT COUNT(*) as total FROM inventory WHERE in_stock = 1");
        $total_inventory = $inventory->fetch_assoc()['total'];
        echo "<p>Available inventory items: <strong>" . $total_inventory . "</strong></p>";
    }
}

echo "<hr>";
echo "<h3>Quick Actions:</h3>";
echo "<ul>";
echo "<li><a href='student/inventory.php'>Go to Available Items</a> - Add items to cart</li>";
echo "<li><a href='student/cart.php'>Go to Shopping Cart</a> - View cart</li>";
echo "<li><a href='database/setup_cart_system.php'>Run Cart Setup</a> - Create tables</li>";
echo "</ul>";

echo "</body></html>";
?>


